package com.example.nirbhaynet;

import android.content.res.AssetFileDescriptor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.tensorflow.lite.Interpreter;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

public class MainActivity extends AppCompatActivity {
    private Interpreter tflite;
    private StandardScaler scaler;
    private EditText typingSpeedInput, swipeSpeedInput, tapPressureInput, deviceAngleInput;
    private TextView resultText;
    private Button predictButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_main);
        } catch (Exception e) {
            // Handle missing layout error
            setContentView(createErrorLayout());
            TextView errorText = findViewById(android.R.id.text1);
            errorText.setText("Error: Layout file missing. Please check activity_main.xml.");
            return;
        }

        // Initialize UI elements
        typingSpeedInput = findViewById(R.id.typing_speed_input);
        swipeSpeedInput = findViewById(R.id.swipe_speed_input);
        tapPressureInput = findViewById(R.id.tap_pressure_input);
        deviceAngleInput = findViewById(R.id.device_angle_input);
        resultText = findViewById(R.id.result_text);
        predictButton = findViewById(R.id.predict_button);

        // Hardcode the scaler values from Colab
        float[] mean = new float[]{45.65284321f, 321.48546237f, 0.55596076f, 34.71889549f};
        float[] scale = new float[]{9.29479523f, 55.26307357f, 0.11470705f, 10.82035121f};
        scaler = new StandardScaler(mean, scale);

        // Load the TFLite model
        try {
            tflite = new Interpreter(loadModelFile());
        } catch (IOException e) {
            resultText.setText("Error loading model: " + e.getMessage());
            predictButton.setEnabled(false);  // Disable button if model fails to load
            return;
        }

        // Set up the predict button (using traditional OnClickListener for compatibility)
        predictButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                predict();
            }
        });
    }

    private MappedByteBuffer loadModelFile() throws IOException {
        AssetFileDescriptor fileDescriptor = getAssets().openFd("nn_model.tflite");
        try (FileInputStream inputStream = new FileInputStream(fileDescriptor.getFileDescriptor())) {
            FileChannel fileChannel = inputStream.getChannel();
            long startOffset = fileDescriptor.getStartOffset();
            long declaredLength = fileDescriptor.getLength();
            return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);
        }
    }

    private void predict() {
        try {
            // Get user inputs with validation
            if (typingSpeedInput.getText().toString().isEmpty() ||
                swipeSpeedInput.getText().toString().isEmpty() ||
                tapPressureInput.getText().toString().isEmpty() ||
                deviceAngleInput.getText().toString().isEmpty()) {
                resultText.setText("Error: All fields must be filled.");
                return;
            }

            float typingSpeed = Float.parseFloat(typingSpeedInput.getText().toString());
            float swipeSpeed = Float.parseFloat(swipeSpeedInput.getText().toString());
            float tapPressure = Float.parseFloat(tapPressureInput.getText().toString());
            float deviceAngle = Float.parseFloat(deviceAngleInput.getText().toString());

            // Prepare input data
            float[][] input = new float[1][4];
            input[0][0] = typingSpeed;
            input[0][1] = swipeSpeed;
            input[0][2] = tapPressure;
            input[0][3] = deviceAngle;

            // Standardize the input using the scaler
            input[0] = scaler.transform(input[0]);

            // Run inference
            float[][] output = new float[1][1];
            tflite.run(input, output);

            // Interpret the result
            float prediction = output[0][0];
            resultText.setText(prediction > 0.5 ? "Fraud Detected" : "Normal Behavior");
        } catch (NumberFormatException e) {
            resultText.setText("Error: Please enter valid numbers.");
        } catch (Exception e) {
            resultText.setText("Error during prediction: " + e.getMessage());
        }
    }

    // Fallback layout if activity_main.xml is missing
    private View createErrorLayout() {
        TextView errorText = new TextView(this);
        errorText.setId(android.R.id.text1);
        errorText.setText("Layout error");
        errorText.setTextSize(18);
        errorText.setPadding(16, 16, 16, 16);
        return errorText;
    }

    // Custom StandardScaler class
    static class StandardScaler {
        private final float[] mean;
        private final float[] scale;

        public StandardScaler(float[] mean, float[] scale) {
            this.mean = mean;
            this.scale = scale;
        }

        public float[] transform(float[] input) {
            if (input.length != mean.length || input.length != scale.length) {
                throw new IllegalArgumentException("Input size must match scaler dimensions");
            }
            float[] transformed = new float[input.length];
            for (int i = 0; i < input.length; i++) {
                transformed[i] = (input[i] - mean[i]) / scale[i];
            }
            return transformed;
        }
    }
}